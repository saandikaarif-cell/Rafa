<?php
/**
 * about.php - Halaman Tentang Kami
 */

require_once 'config/database.php';
require_once 'includes/auth.php';

require_once 'includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-4 p-md-5 text-center">
                <h1 class="fw-bold mb-3">Tentang Bookstore</h1>
                <p class="lead mb-0 opacity-75">Temukan dunia baru di setiap halaman.</p>
            </div>
        </div>

        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-4 p-md-5">
                <h2 class="fw-bold mb-4">Cerita Kami</h2>
                <p>Bookstore lahir dari cinta terhadap buku dan kepercayaan bahwa membaca adalah kunci pengetahuan, imajinasi, dan pertumbuhan pribadi.</p>
                <p>Kami membuat buku berkualitas mudah diakses oleh semua orang dan berkembang menjadi toko buku online yang dipercaya ribuan pembaca di Indonesia.</p>
                <p>Setiap buku dipilih dengan cermat, dari fiksi klasik hingga bestseller terkini. Kami tidak hanya menjual buku, kami membangun komunitas pembaca.</p>
            </div>
        </div>

        <div class="card border-0 shadow-sm">
            <div class="card-body p-4 p-md-5">
                <h2 class="fw-bold mb-4">Informasi Perusahaan</h2>
                <p class="mb-0"><i class="bi bi-geo-alt me-2"></i> Jl. Buku No. 123, Jakarta Pusat</p>
                <p class="mb-0"><i class="bi bi-telephone me-2"></i> +62 21 1234 5678</p>
                <p class="mb-0"><i class="bi bi-envelope me-2"></i> info@bookstore.com</p>
                <p class="mb-0"><i class="bi bi-clock me-2"></i> Senin - Jumat, 09:00 - 18:00 WIB</p>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
