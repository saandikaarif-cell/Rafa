<?php
/**
 * account.php - Pengaturan akun user
 * Ubah profil (nama, email) dan kata sandi.
 */

require_once 'config/database.php';
require_once 'includes/auth.php';

if (!isLoggedIn() || isAdmin()) {
    setFlash('message', 'Silakan login sebagai user untuk mengakses pengaturan akun.');
    redirect('login.php');
}

$userId = getUserId();
$stmt = $pdo->prepare("SELECT id, name, email, role, created_at FROM users WHERE id = ? AND role = 'user'");
$stmt->execute([$userId]);
$user = $stmt->fetch();
if (!$user) {
    redirect('logout.php');
}

$profileErrors = [];
$passwordErrors = [];
$profileOk = getFlash('profile_ok');
$passwordOk = getFlash('password_ok');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'profile') {
        $name  = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');

        if ($name === '') {
            $profileErrors[] = 'Nama lengkap wajib diisi.';
        }
        if ($email === '') {
            $profileErrors[] = 'Email wajib diisi.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $profileErrors[] = 'Format email tidak valid.';
        }
        if (empty($profileErrors)) {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id <> ?");
            $stmt->execute([$email, $userId]);
            if ($stmt->fetch()) {
                $profileErrors[] = 'Email sudah digunakan akun lain.';
            }
        }
        if (empty($profileErrors)) {
            $stmt = $pdo->prepare("UPDATE users SET name = ?, email = ? WHERE id = ? AND role = 'user'");
            $stmt->execute([$name, $email, $userId]);
            $_SESSION['name'] = $name;
            setFlash('profile_ok', 'Profil berhasil diperbarui.');
            redirect('account.php');
        }
        $user['name'] = $name;
        $user['email'] = $email;
    }

    if ($action === 'password') {
        $current = $_POST['current_password'] ?? '';
        $new     = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';

        $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ? AND role = 'user'");
        $stmt->execute([$userId]);
        $row = $stmt->fetch();

        if ($current === '' || !password_verify($current, $row['password'] ?? '')) {
            $passwordErrors[] = 'Kata sandi saat ini salah.';
        }
        if ($new === '') {
            $passwordErrors[] = 'Kata sandi baru wajib diisi.';
        } elseif (strlen($new) < 6) {
            $passwordErrors[] = 'Kata sandi baru minimal 6 karakter.';
        }
        if ($new !== $confirm) {
            $passwordErrors[] = 'Konfirmasi kata sandi tidak cocok.';
        }
        if ($new !== '' && $current !== '' && $new === $current) {
            $passwordErrors[] = 'Kata sandi baru harus berbeda dari kata sandi saat ini.';
        }
        if (empty($passwordErrors)) {
            $hash = password_hash($new, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ? AND role = 'user'");
            $stmt->execute([$hash, $userId]);
            setFlash('password_ok', 'Kata sandi berhasil diubah.');
            redirect('account.php');
        }
    }
}

require_once 'includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="card shadow-sm mb-4">
            <div class="card-header">
                <h4 class="mb-0"><i class="bi bi-person-gear me-2"></i>Pengaturan Akun</h4>
            </div>
            <div class="card-body">
                <div class="row mb-4 pb-4 border-bottom">
                    <div class="col-auto">
                        <div class="avatar-lg bg-primary-soft text-primary rounded-circle d-flex align-items-center justify-content-center" style="width:80px;height:80px;">
                            <i class="bi bi-person" style="font-size:32px;"></i>
                        </div>
                    </div>
                    <div class="col ps-3">
                        <h5 class="mb-1"><?= htmlspecialchars($user['name']) ?></h5>
                        <p class="text-muted mb-1"><?= htmlspecialchars($user['email']) ?></p>
                        <small class="text-muted">Terdaftar sejak <?= date('d M Y', strtotime($user['created_at'])) ?></small>
                    </div>
                </div>

                <div class="row g-4">
                    <div class="col-md-6">
                        <div class="card h-100">
                            <div class="card-header"><h5 class="mb-0">Profil</h5></div>
                            <div class="card-body">
                                <?php if ($profileOk): ?>
                                    <div class="alert alert-success"><?= htmlspecialchars($profileOk) ?></div>
                                <?php endif; ?>
                                <?php if (!empty($profileErrors)): ?>
                                    <div class="alert alert-danger">
                                        <ul class="mb-0"><?php foreach ($profileErrors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?></ul>
                                    </div>
                                <?php endif; ?>
                                <form method="POST" action="account.php">
                                    <input type="hidden" name="action" value="profile">
                                    <div class="mb-3">
                                        <label class="form-label">Nama Lengkap</label>
                                        <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($user['name']) ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Email</label>
                                        <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" required>
                                    </div>
                                    <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg me-1"></i>Simpan Profil</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card h-100">
                            <div class="card-header"><h5 class="mb-0">Ubah Kata Sandi</h5></div>
                            <div class="card-body">
                                <?php if ($passwordOk): ?>
                                    <div class="alert alert-success"><?= htmlspecialchars($passwordOk) ?></div>
                                <?php endif; ?>
                                <?php if (!empty($passwordErrors)): ?>
                                    <div class="alert alert-danger">
                                        <ul class="mb-0"><?php foreach ($passwordErrors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?></ul>
                                    </div>
                                <?php endif; ?>
                                <form method="POST" action="account.php">
                                    <input type="hidden" name="action" value="password">
                                    <div class="mb-3">
                                        <label class="form-label">Kata Sandi Saat Ini</label>
                                        <input type="password" name="current_password" class="form-control" required autocomplete="current-password">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Kata Sandi Baru</label>
                                        <input type="password" name="new_password" class="form-control" minlength="6" required autocomplete="new-password">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Konfirmasi Kata Sandi Baru</label>
                                        <input type="password" name="confirm_password" class="form-control" required autocomplete="new-password">
                                    </div>
                                    <button type="submit" class="btn btn-primary"><i class="bi bi-shield-lock me-1"></i>Ubah Kata Sandi</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>