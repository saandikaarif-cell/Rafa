<?php
/**
 * admin/includes/footer.php
 * Footer panel admin.
 */
?>
        </main>

        <!-- Footer -->
        <footer class="admin-footer">
            <div class="footer-content">
                <div class="footer-brand">
                    <img src="../assets/image/logo-bookstore.svg" alt="Bookstore">
                    <span>&copy; <?= date('Y') ?> Bookstore Admin Panel</span>
                </div>
                <div class="footer-links">
                    <a href="../index.php" target="_blank">Lihat Toko</a>
                    <a href="../logout.php">Keluar</a>
                </div>
            </div>
        </footer>
    </div>
</div>

<!-- Bootstrap 5 JS + Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Sidebar toggle for mobile
    const sidebar = document.getElementById('adminSidebar');
    const overlay = document.getElementById('sidebarOverlay');
    const toggle = document.getElementById('sidebarToggle');

    if (toggle && sidebar && overlay) {
        toggle.addEventListener('click', function() {
            sidebar.classList.toggle('open');
            overlay.classList.toggle('open');
        });

        overlay.addEventListener('click', function() {
            sidebar.classList.remove('open');
            overlay.classList.remove('open');
        });

        // Close sidebar when clicking a link on mobile
        sidebar.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', function() {
                if (window.innerWidth < 992) {
                    sidebar.classList.remove('open');
                    overlay.classList.remove('open');
                }
            });
        });
    }
</script>
</body>
</html>