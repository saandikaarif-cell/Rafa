<?php
/**
 * admin/includes/header.php
 * Header HTML untuk panel admin.
 */
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Bookstore</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .admin-wrapper {
            display: flex;
            min-height: 100vh;
        }
        .admin-sidebar {
            width: 260px;
            background: #fff;
            border-right: 1px solid #e1e8f0;
            min-height: 100vh;
            position: sticky;
            top: 0;
            height: 100vh;
            overflow-y: auto;
            z-index: 100;
        }
        .admin-sidebar .sidebar-header {
            padding: 24px 20px;
            border-bottom: 1px solid #e1e8f0;
            background: linear-gradient(135deg, #f8faff 0%, #eef5ff 100%);
        }
        .admin-sidebar .sidebar-header .brand {
            display: flex;
            align-items: center;
            gap: 12px;
            text-decoration: none;
            color: #1e3c72;
        }
        .admin-sidebar .sidebar-header .brand img {
            height: 36px;
            width: auto;
        }
        .admin-sidebar .sidebar-header .brand span {
            font-weight: 700;
            font-size: 18px;
            letter-spacing: 0.3px;
        }
        .admin-sidebar .nav {
            padding: 16px 12px;
        }
        .admin-sidebar .nav-item {
            margin-bottom: 4px;
        }
        .admin-sidebar .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            color: #4a5568;
            border-radius: 10px;
            font-weight: 500;
            font-size: 14.5px;
            transition: all 0.2s ease;
            text-decoration: none;
        }
        .admin-sidebar .nav-link:hover {
            background: #eef5ff;
            color: #2f80ed;
        }
        .admin-sidebar .nav-link.active {
            background: linear-gradient(135deg, #2f80ed 0%, #1e3c72 100%);
            color: #fff;
            box-shadow: 0 4px 14px rgba(47, 128, 237, 0.3);
        }
        .admin-sidebar .nav-link i {
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
        }
        .admin-main {
            flex: 1;
            background: #f6f9fc;
            min-height: 100vh;
        }
        .admin-navbar {
            background: #fff;
            border-bottom: 1px solid #e1e8f0;
            padding: 0 24px;
            height: 64px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 50;
        }
        .admin-navbar .page-title {
            font-size: 20px;
            font-weight: 600;
            color: #1e3c72;
            margin: 0;
        }
        .admin-navbar .user-menu .dropdown-toggle {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 8px 14px;
            border-radius: 10px;
            color: #4a5568;
            text-decoration: none;
            font-weight: 500;
            font-size: 14px;
            background: transparent;
            border: none;
            transition: all 0.2s;
        }
        .admin-navbar .user-menu .dropdown-toggle:hover {
            background: #f6f9fc;
            color: #2f80ed;
        }
        .admin-navbar .user-menu .dropdown-toggle::after {
            display: none;
        }
        .admin-navbar .user-menu .avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: linear-gradient(135deg, #2f80ed 0%, #1e3c72 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-weight: 600;
            font-size: 14px;
        }
        .admin-navbar .dropdown-menu {
            border: none;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border-radius: 12px;
            padding: 8px;
            min-width: 200px;
        }
        .admin-navbar .dropdown-item {
            padding: 10px 14px;
            border-radius: 8px;
            font-size: 14px;
            color: #4a5568;
            transition: all 0.2s;
        }
        .admin-navbar .dropdown-item:hover {
            background: #eef5ff;
            color: #2f80ed;
        }
        .admin-navbar .dropdown-item i {
            width: 18px;
            margin-right: 8px;
        }
        .admin-content {
            padding: 24px;
        }
        .admin-footer {
            background: #fff;
            border-top: 1px solid #e1e8f0;
            padding: 20px 24px;
            margin-top: auto;
        }
        .admin-footer .footer-content {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 12px;
        }
        .admin-footer .footer-brand {
            display: flex;
            align-items: center;
            gap: 10px;
            color: #6c757d;
            font-size: 13px;
        }
        .admin-footer .footer-brand img {
            height: 28px;
        }
        .admin-footer .footer-links a {
            color: #6c757d;
            text-decoration: none;
            font-size: 13px;
            margin-left: 20px;
            transition: color 0.2s;
        }
        .admin-footer .footer-links a:hover {
            color: #2f80ed;
        }
        @media (max-width: 991px) {
            .admin-sidebar {
                position: fixed;
                left: -260px;
                transition: left 0.3s ease;
                box-shadow: 0 0 30px rgba(0,0,0,0.1);
                z-index: 1050;
            }
            .admin-sidebar.open {
                left: 0;
            }
            .admin-sidebar-overlay {
                display: none;
                position: fixed;
                inset: 0;
                background: rgba(0,0,0,0.4);
                z-index: 1040;
            }
            .admin-sidebar-overlay.open {
                display: block;
            }
            .admin-navbar .sidebar-toggle {
                display: flex;
            }
        }
        @media (min-width: 992px) {
            .admin-navbar .sidebar-toggle {
                display: none;
            }
        }
    </style>
</head>
<body>
<div class="admin-wrapper">
    <!-- Sidebar -->
    <aside class="admin-sidebar" id="adminSidebar">
        <div class="sidebar-header">
            <a href="index.php" class="brand">
                <img src="../assets/image/logo-bookstore.svg" alt="Bookstore">
                <span>Admin Panel</span>
            </a>
        </div>
        <nav class="nav flex-column">
            <a href="index.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'index.php' ? 'active' : '' ?>">
                <i class="bi bi-speedometer2"></i> Dashboard
            </a>
            <a href="books.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'books.php' ? 'active' : '' ?>">
                <i class="bi bi-book"></i> Buku
            </a>
            <a href="categories.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'categories.php' ? 'active' : '' ?>">
                <i class="bi bi-folder"></i> Kategori
            </a>
            <a href="users.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'users.php' ? 'active' : '' ?>">
                <i class="bi bi-people"></i> User
            </a>
            <a href="orders.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'orders.php' ? 'active' : '' ?>">
                <i class="bi bi-receipt"></i> Pesanan
            </a>
            <a href="messages.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'messages.php' ? 'active' : '' ?>">
                <i class="bi bi-envelope"></i> Pesan
            </a>
        </nav>
    </aside>

    <!-- Overlay for mobile -->
    <div class="admin-sidebar-overlay" id="sidebarOverlay"></div>

    <!-- Main Content -->
    <div class="admin-main">
        <!-- Top Navbar -->
        <header class="admin-navbar">
            <button class="btn btn-link text-dark p-0 sidebar-toggle d-flex align-items-center justify-content-center" 
                    id="sidebarToggle" style="width:40px;height:40px;border-radius:10px;" 
                    aria-label="Toggle sidebar">
                <i class="bi bi-list" style="font-size:20px;"></i>
            </button>
            <h1 class="page-title"><?= $pageTitle ?? 'Dashboard' ?></h1>
            <div class="user-menu dropdown">
                <button class="dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <div class="avatar"><?= strtoupper(substr($_SESSION['name'] ?? 'A', 0, 1)) ?></div>
                    <span><?= htmlspecialchars($_SESSION['name'] ?? 'Admin') ?></span>
                    <i class="bi bi-chevron-down" style="font-size:11px;"></i>
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="../index.php"><i class="bi bi-shop"></i> Lihat Toko</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="../logout.php"><i class="bi bi-box-arrow-right"></i> Keluar</a></li>
                </ul>
            </div>
        </header>

        <!-- Page Content -->
        <main class="admin-content" id="adminContent">