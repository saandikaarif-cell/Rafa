<?php
/**
 * admin/index.php - Dashboard Admin
 */

require_once '../config/database.php';
require_once '../includes/auth.php';

// Cek admin login
if (!isLoggedIn() || !isAdmin()) {
    redirect('login.php');
}

// Statistik
$totalBooks = $pdo->query("SELECT COUNT(*) FROM books")->fetchColumn();
$totalCategories = $pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn();
$totalUsers = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'user'")->fetchColumn();
$totalOrders = $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
$pendingOrders = $pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'pending'")->fetchColumn();
$totalRevenue = $pdo->query("SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE status != 'pending'")->fetchColumn();

// Pesanan terbaru
$stmt = $pdo->query("
    SELECT o.*, u.name as user_name 
    FROM orders o 
    LEFT JOIN users u ON o.user_id = u.id 
    ORDER BY o.created_at DESC 
    LIMIT 5
");
$recentOrders = $stmt->fetchAll();

$pageTitle = 'Dashboard';
require_once 'includes/header.php';
?>

<!-- Stats Cards -->
<div class="row g-4 mb-4">
    <div class="col-md-3">
        <div class="card stat-card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <p class="text-muted mb-1 small">Total Buku</p>
                        <h3 class="mb-0 fw-bold"><?= number_format($totalBooks) ?></h3>
                    </div>
                    <div class="stat-icon bg-primary-soft text-primary rounded-circle d-flex align-items-center justify-content-center" style="width:48px;height:48px;">
                        <i class="bi bi-book" style="font-size:20px;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card stat-card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <p class="text-muted mb-1 small">Total Kategori</p>
                        <h3 class="mb-0 fw-bold"><?= number_format($totalCategories) ?></h3>
                    </div>
                    <div class="stat-icon bg-success-soft text-success rounded-circle d-flex align-items-center justify-content-center" style="width:48px;height:48px;">
                        <i class="bi bi-folder" style="font-size:20px;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card stat-card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <p class="text-muted mb-1 small">Pengguna</p>
                        <h3 class="mb-0 fw-bold"><?= number_format($totalUsers) ?></h3>
                    </div>
                    <div class="stat-icon bg-info-soft text-info rounded-circle d-flex align-items-center justify-content-center" style="width:48px;height:48px;">
                        <i class="bi bi-people" style="font-size:20px;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card stat-card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <p class="text-muted mb-1 small">Total Pesanan</p>
                        <h3 class="mb-0 fw-bold"><?= number_format($totalOrders) ?></h3>
                    </div>
                    <div class="stat-icon bg-warning-soft text-warning rounded-circle d-flex align-items-center justify-content-center" style="width:48px;height:48px;">
                        <i class="bi bi-receipt" style="font-size:20px;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    <!-- Pendapatan & Pesanan Pending -->
    <div class="col-lg-4">
        <div class="row g-3">
            <div class="col-12">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <p class="text-muted mb-1 small">Pendapatan</p>
                                <h3 class="mb-0 fw-bold text-success">Rp <?= number_format($totalRevenue, 0, ',', '.') ?></h3>
                            </div>
                            <div class="stat-icon bg-success-soft text-success rounded-circle d-flex align-items-center justify-content-center" style="width:48px;height:48px;">
                                <i class="bi bi-currency-rupee" style="font-size:20px;"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <p class="text-muted mb-1 small">Pesanan Pending</p>
                                <h3 class="mb-0 fw-bold text-warning"><?= number_format($pendingOrders) ?></h3>
                            </div>
                            <div class="stat-icon bg-warning-soft text-warning rounded-circle d-flex align-items-center justify-content-center" style="width:48px;height:48px;">
                                <i class="bi bi-clock" style="font-size:20px;"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Pesanan Terbaru -->
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white border-0 pb-0">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="mb-0 fw-semibold"><i class="bi bi-receipt me-2"></i>Pesanan Terbaru</h5>
                    <a href="orders.php" class="btn btn-sm btn-outline-primary">Lihat Semua</a>
                </div>
            </div>
            <div class="card-body p-0">
                <?php if (count($recentOrders) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>ID</th>
                                    <th>Pelanggan</th>
                                    <th>Total</th>
                                    <th>Status</th>
                                    <th>Tanggal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentOrders as $order): 
                                    $statusClass = [
                                        'pending' => 'warning',
                                        'processing' => 'info',
                                        'shipped' => 'primary',
                                        'delivered' => 'success'
                                    ][$order['status']] ?? 'secondary';
                                    $statusLabel = [
                                        'pending' => 'Menunggu',
                                        'processing' => 'Diproses',
                                        'shipped' => 'Dikirim',
                                        'delivered' => 'Selesai'
                                    ][$order['status']] ?? $order['status'];
                                ?>
                                    <tr>
                                        <td class="fw-medium">#<?= $order['id'] ?></td>
                                        <td><?= htmlspecialchars($order['name']) ?></td>
                                        <td class="fw-medium">Rp <?= number_format($order['total_amount'], 0, ',', '.') ?></td>
                                        <td><span class="badge bg-<?= $statusClass ?>"><?= $statusLabel ?></span></td>
                                        <td class="text-muted small"><?= date('d M Y H:i', strtotime($order['created_at'])) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="bi bi-receipt display-1 text-muted"></i>
                        <p class="text-muted mt-3">Belum ada pesanan.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<style>
    .stat-card { transition: transform 0.2s ease, box-shadow 0.2s ease; }
    .stat-card:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(0,0,0,0.08) !important; }
    .stat-icon { font-size: 20px; }
    .bg-primary-soft { background: rgba(47, 128, 237, 0.12) !important; }
    .bg-success-soft { background: rgba(25, 135, 84, 0.12) !important; }
    .bg-info-soft { background: rgba(13, 202, 240, 0.12) !important; }
    .bg-warning-soft { background: rgba(255, 193, 7, 0.12) !important; }
</style>

<?php require_once 'includes/footer.php'; ?>