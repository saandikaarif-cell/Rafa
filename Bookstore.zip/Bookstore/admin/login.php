<?php
/**
 * admin/login.php - Halaman login admin
 */

require_once '../config/database.php';
require_once '../includes/auth.php';

// Jika sudah login sebagai admin, redirect ke dashboard
if (isLoggedIn() && isAdmin()) {
    redirect('index.php');
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $errors[] = 'Email dan password wajib diisi.';
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare("SELECT id, name, password, role FROM users WHERE email = ? AND role = 'admin'");
        $stmt->execute([$email]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($password, $admin['password'])) {
            $_SESSION['user_id'] = $admin['id'];
            $_SESSION['name']    = $admin['name'];
            $_SESSION['role']    = 'admin';

            redirect('index.php');
        } else {
            $errors[] = 'Email atau password salah, atau akun bukan admin.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Bookstore</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .admin-login-body {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            padding: 20px;
        }
        .admin-login-card {
            width: 100%;
            max-width: 420px;
            border: none;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.15);
            overflow: hidden;
        }
        .admin-login-header {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 32px 24px 24px;
            text-align: center;
        }
        .admin-login-header .logo {
            width: 70px;
            height: 70px;
            background: rgba(255,255,255,0.15);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 16px;
            font-size: 28px;
        }
        .admin-login-header h3 {
            margin: 0;
            font-weight: 600;
            font-size: 22px;
        }
        .admin-login-header p {
            margin: 8px 0 0;
            opacity: 0.85;
            font-size: 14px;
        }
        .admin-login-body-content {
            padding: 32px 28px;
            background: #fff;
        }
        .form-floating > label {
            color: #6c757d;
        }
        .form-control {
            border-radius: 10px;
            border: 1px solid #e1e8f0;
            padding: 14px 16px;
            font-size: 15px;
            transition: all 0.2s ease;
        }
        .form-control:focus {
            border-color: #2f80ed;
            box-shadow: 0 0 0 3px rgba(47, 128, 237, 0.15);
        }
        .form-floating > .form-control:focus ~ label,
        .form-floating > .form-control:not(:placeholder-shown) ~ label {
            color: #2f80ed;
        }
        .btn-login {
            background: linear-gradient(135deg, #2f80ed 0%, #1e3c72 100%);
            border: none;
            border-radius: 10px;
            padding: 14px;
            font-weight: 600;
            font-size: 15px;
            letter-spacing: 0.3px;
            transition: all 0.2s ease;
        }
        .btn-login:hover {
            transform: translateY(-1px);
            box-shadow: 0 8px 20px rgba(47, 128, 237, 0.35);
        }
        .alert {
            border-radius: 10px;
            border: none;
            font-size: 14px;
        }
        .back-link {
            text-align: center;
            margin-top: 20px;
        }
        .back-link a {
            color: #6c757d;
            text-decoration: none;
            font-size: 14px;
            transition: color 0.2s;
        }
        .back-link a:hover {
            color: #2f80ed;
        }
    </style>
</head>
<body class="admin-login-body">
<div class="card admin-login-card">
    <div class="admin-login-header">
        <div class="logo">
            <i class="bi bi-shield-lock"></i>
        </div>
        <h3>Admin Panel</h3>
        <p>Bookstore Management System</p>
    </div>
    <div class="admin-login-body-content">
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger d-flex align-items-center" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2"></i>
                <div>
                    <?php foreach ($errors as $error): ?>
                        <div><?= $error ?></div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <form method="POST" action="login.php">
            <div class="form-floating mb-3">
                <input type="email" name="email" class="form-control" id="email"
                       placeholder="admin@bookstore.com" required autofocus autocomplete="email">
                <label for="email"><i class="bi bi-envelope me-2"></i>Email</label>
            </div>
            <div class="form-floating mb-4">
                <input type="password" name="password" class="form-control" id="password"
                       placeholder="Password" required autocomplete="current-password">
                <label for="password"><i class="bi bi-lock me-2"></i>Password</label>
            </div>
            <button type="submit" class="btn btn-primary btn-login w-100">
                <i class="bi bi-box-arrow-in-right me-2"></i>Masuk ke Dashboard
            </button>
        </form>

        <div class="back-link">
            <a href="../index.php"><i class="bi bi-arrow-left me-1"></i>Kembali ke Toko</a>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>