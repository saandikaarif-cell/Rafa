<?php
/**
 * admin/messages.php - Kelola pesan dari pelanggan
 */

require_once '../config/database.php';
require_once '../includes/auth.php';

// Cek admin login
if (!isLoggedIn() || !isAdmin()) {
    redirect('login.php');
}

$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$perPage = 20;
$offset = ($page - 1) * $perPage;

$statusFilter = isset($_GET['status']) ? $_GET['status'] : '';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

$where = " WHERE 1=1";
$params = [];

if ($statusFilter !== '' && in_array($statusFilter, ['read', 'unread'])) {
    $where .= " AND m.is_read = :status";
    $params[':status'] = $statusFilter === 'read' ? 1 : 0;
}

if ($search !== '') {
    $where .= " AND (m.name LIKE :search OR m.email LIKE :search OR m.subject LIKE :search)";
    $params[':search'] = "%$search%";
}

$countSql = "SELECT COUNT(*) FROM messages m" . $where;
$countStmt = $pdo->prepare($countSql);
$countStmt->execute($params);
$totalMessages = (int)$countStmt->fetchColumn();
$totalPages = max(1, (int)ceil($totalMessages / $perPage));

$sql = "SELECT m.*, u.name as user_name 
        FROM messages m
        LEFT JOIN users u ON m.user_id = u.id" . $where . "
        ORDER BY m.created_at DESC
        LIMIT :limit OFFSET :offset";
$stmt = $pdo->prepare($sql);
foreach ($params as $k => $v) {
    $stmt->bindValue($k, $v);
}
$stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$messages = $stmt->fetchAll();

// Handle mark as read/unread
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $messageId = (int)$_POST['message_id'];
    if ($_POST['action'] === 'mark_read') {
        $pdo->prepare("UPDATE messages SET is_read = 1 WHERE id = ?")->execute([$messageId]);
    } elseif ($_POST['action'] === 'mark_unread') {
        $pdo->prepare("UPDATE messages SET is_read = 0 WHERE id = ?")->execute([$messageId]);
    } elseif ($_POST['action'] === 'delete') {
        $pdo->prepare("DELETE FROM messages WHERE id = ?")->execute([$messageId]);
    }
    header("Location: messages.php?" . http_build_query(array_filter(['page' => $page, 'status' => $statusFilter, 'search' => $search])));
    exit;
}

// Get unread count for badge
$unreadCount = $pdo->query("SELECT COUNT(*) FROM messages WHERE is_read = 0")->fetchColumn();

$pageTitle = 'Pesan Pelanggan';
require_once 'includes/header.php';
?>

<h1 class="mb-4"><i class="bi bi-envelope"></i> Pesan Pelanggan</h1>

<!-- Stats & Filter -->
<div class="row mb-4 g-3">
    <div class="col-auto">
        <div class="d-flex gap-2">
            <a href="messages.php" class="btn btn-sm <?= $statusFilter === '' ? 'btn-primary' : 'btn-outline-primary' ?>">Semua</a>
            <a href="messages.php?status=unread" class="btn btn-sm <?= $statusFilter === 'unread' ? 'btn-warning' : 'btn-outline-warning' ?>">
                <i class="bi bi-envelope me-1"></i>Belum Dibaca (<?= $unreadCount ?>)
            </a>
            <a href="messages.php?status=read" class="btn btn-sm <?= $statusFilter === 'read' ? 'btn-success' : 'btn-outline-success' ?>">
                <i class="bi bi-envelope-open me-1"></i>Sudah Dibaca
            </a>
        </div>
    </div>
    <div class="col-auto ms-auto">
        <form method="GET" action="messages.php" class="d-flex gap-2">
            <?php if ($statusFilter): ?>
                <input type="hidden" name="status" value="<?= htmlspecialchars($statusFilter) ?>">
            <?php endif; ?>
            <input type="text" name="search" class="form-control form-control-sm" style="width:250px"
                   placeholder="Cari nama/email/subjek..." value="<?= htmlspecialchars($search) ?>">
            <button type="submit" class="btn btn-sm btn-outline-secondary">
                <i class="bi bi-search"></i>
            </button>
        </form>
    </div>
</div>

<!-- Messages List -->
<div class="card border-0 shadow-sm">
    <div class="card-header bg-white border-0">
        <h5 class="mb-0"><i class="bi bi-list-ul me-2"></i>Daftar Pesan</h5>
    </div>
    <div class="card-body p-0">
        <?php if (count($messages) > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Pengirim</th>
                            <th>Subjek</th>
                            <th>Pratinjau Pesan</th>
                            <th>Status</th>
                            <th>Tanggal</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($messages as $message): ?>
                            <tr class="<?= !$message['is_read'] ? 'fw-bold bg-light' : '' ?>">
                                <td>#<?= $message['id'] ?></td>
                                <td>
                                    <div>
                                        <div class="fw-medium"><?= htmlspecialchars($message['name']) ?></div>
                                        <small class="text-muted"><?= htmlspecialchars($message['email']) ?></small>
                                        <?php if ($message['user_id']): ?>
                                            <span class="badge bg-light text-dark ms-1">User: <?= htmlspecialchars($message['user_name']) ?></span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td class="fw-medium"><?= htmlspecialchars($message['subject']) ?></td>
                                <td>
                                    <div class="text-muted small" style="max-width: 300px;">
                                        <?= htmlspecialchars(mb_substr($message['message'], 0, 100)) ?>...
                                    </div>
                                </td>
                                <td>
                                    <?php if ($message['is_read']): ?>
                                        <span class="badge bg-success"><i class="bi bi-envelope-open me-1"></i>Dibaca</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning text-dark"><i class="bi bi-envelope me-1"></i>Belum Dibaca</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-muted small"><?= date('d M Y H:i', strtotime($message['created_at'])) ?></td>
                                <td class="text-center">
                                    <div class="btn-group btn-group-sm">
                                        <?php if (!$message['is_read']): ?>
                                            <form method="POST" action="messages.php" class="d-inline">
                                                <input type="hidden" name="message_id" value="<?= $message['id'] ?>">
                                                <input type="hidden" name="action" value="mark_read">
                                                <?php if ($statusFilter): ?>
                                                    <input type="hidden" name="status" value="<?= htmlspecialchars($statusFilter) ?>">
                                                <?php endif; ?>
                                                <?php if ($search): ?>
                                                    <input type="hidden" name="search" value="<?= htmlspecialchars($search) ?>">
                                                <?php endif; ?>
                                                <input type="hidden" name="page" value="<?= $page ?>">
                                                <button type="submit" class="btn btn-outline-success" title="Tandai Dibaca">
                                                    <i class="bi bi-check"></i>
                                                </button>
                                            </form>
                                        <?php else: ?>
                                            <form method="POST" action="messages.php" class="d-inline">
                                                <input type="hidden" name="message_id" value="<?= $message['id'] ?>">
                                                <input type="hidden" name="action" value="mark_unread">
                                                <?php if ($statusFilter): ?>
                                                    <input type="hidden" name="status" value="<?= htmlspecialchars($statusFilter) ?>">
                                                <?php endif; ?>
                                                <?php if ($search): ?>
                                                    <input type="hidden" name="search" value="<?= htmlspecialchars($search) ?>">
                                                <?php endif; ?>
                                                <input type="hidden" name="page" value="<?= $page ?>">
                                                <button type="submit" class="btn btn-outline-warning" title="Tandai Belum Dibaca">
                                                    <i class="bi bi-envelope"></i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                        <button type="button" class="btn btn-outline-primary btn-sm" 
                                                data-bs-toggle="collapse" 
                                                data-bs-target="#detailRow<?= $message['id'] ?>"
                                                aria-expanded="false"
                                                aria-controls="detailRow<?= $message['id'] ?>"
                                                title="Lihat Detail">
                                            <i class="bi bi-eye"></i>
                                        </button>
                                        <form method="POST" action="messages.php" class="d-inline" onsubmit="return confirm('Hapus pesan ini?')">
                                            <input type="hidden" name="message_id" value="<?= $message['id'] ?>">
                                            <input type="hidden" name="action" value="delete">
                                            <?php if ($statusFilter): ?>
                                                <input type="hidden" name="status" value="<?= htmlspecialchars($statusFilter) ?>">
                                            <?php endif; ?>
                                            <?php if ($search): ?>
                                                <input type="hidden" name="search" value="<?= htmlspecialchars($search) ?>">
                                            <?php endif; ?>
                                            <input type="hidden" name="page" value="<?= $page ?>">
                                            <button type="submit" class="btn btn-outline-danger btn-sm" title="Hapus">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <!-- Inline Detail Row -->
                            <tr>
                                <td colspan="8" class="p-0">
                                    <div class="collapse" id="detailRow<?= $message['id'] ?>">
                                        <div class="card border-0 mb-2 bg-light">
                                            <div class="card-body p-3">
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <strong>Nama:</strong> <?= htmlspecialchars($message['name']) ?>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <strong>Email:</strong> <?= htmlspecialchars($message['email']) ?>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <strong>Tanggal:</strong> <?= date('d M Y H:i', strtotime($message['created_at'])) ?>
                                                    </div>
                                                </div>
                                                <?php if ($message['user_id']): ?>
                                                    <div class="row mt-2">
                                                        <div class="col-12">
                                                            <strong>User:</strong> <?= htmlspecialchars($message['user_name']) ?> (ID: <?= $message['user_id'] ?>)
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                                <hr class="my-2">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <strong>Pesan:</strong>
                                                        <div class="mt-2 p-2 bg-white rounded" style="white-space: pre-wrap;"><?= htmlspecialchars($message['message']) ?></div>
                                                    </div>
                                                </div>
                                                <?php if (!$message['is_read']): ?>
                                                    <form method="POST" action="messages.php" class="d-inline mt-2">
                                                        <input type="hidden" name="message_id" value="<?= $message['id'] ?>">
                                                        <input type="hidden" name="action" value="mark_read">
                                                        <?php if ($statusFilter): ?>
                                                            <input type="hidden" name="status" value="<?= htmlspecialchars($statusFilter) ?>">
                                                        <?php endif; ?>
                                                        <?php if ($search): ?>
                                                            <input type="hidden" name="search" value="<?= htmlspecialchars($search) ?>">
                                                        <?php endif; ?>
                                                        <?php if ($page): ?>
                                                            <input type="hidden" name="page" value="<?= $page ?>">
                                                        <?php endif; ?>
                                                        <button type="submit" class="btn btn-sm btn-success">
                                                            <i class="bi bi-check me-1"></i>Tandai Dibaca
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($totalPages > 1): ?>
                <nav aria-label="Navigasi halaman pesan" class="px-4 py-3">
                    <ul class="pagination justify-content-center mb-0">
                        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                            <a class="page-link" href="<?= $page <= 1 ? '#' : 'messages.php?' . htmlspecialchars(http_build_query(array_merge(['page' => $page - 1], $statusFilter ? ['status' => $statusFilter] : [], $search ? ['search' => $search] : []))) ?>">Sebelumnya</a>
                        </li>
                        <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                            <li class="page-item <?= $p === $page ? 'active' : '' ?>">
                                <a class="page-link" href="messages.php?<?= htmlspecialchars(http_build_query(array_merge(['page' => $p], $statusFilter ? ['status' => $statusFilter] : [], $search ? ['search' => $search] : []))) ?>"><?= $p ?></a>
                            </li>
                        <?php endfor; ?>
                        <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
                            <a class="page-link" href="<?= $page >= $totalPages ? '#' : 'messages.php?' . htmlspecialchars(http_build_query(array_merge(['page' => $page + 1], $statusFilter ? ['status' => $statusFilter] : [], $search ? ['search' => $search] : []))) ?>">Selanjutnya</a>
                        </li>
                    </ul>
                    <p class="text-center text-muted small mb-0">Halaman <?= $page ?> dari <?= $totalPages ?> (<?= $totalMessages ?> pesan)</p>
                </nav>
            <?php endif; ?>
        <?php else: ?>
            <div class="text-center py-5">
                <i class="bi bi-envelope display-1 text-muted"></i>
                <p class="text-muted mt-3">Tidak ada pesan ditemukan.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>