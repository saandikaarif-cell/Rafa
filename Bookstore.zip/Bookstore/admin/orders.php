<?php
/**
 * admin/orders.php - Kelola pesanan dari semua user
 */

require_once '../config/database.php';
require_once '../includes/auth.php';

// Cek admin login
if (!isLoggedIn() || !isAdmin()) {
    redirect('login.php');
}

$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$perPage = 20;
$offset = ($page - 1) * $perPage;

$statusFilter = isset($_GET['status']) ? $_GET['status'] : '';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

$where = " WHERE 1=1";
$params = [];

if ($statusFilter !== '' && in_array($statusFilter, ['pending', 'processing', 'shipped', 'delivered'])) {
    $where .= " AND o.status = :status";
    $params[':status'] = $statusFilter;
}

if ($search !== '') {
    $where .= " AND (o.name LIKE :search OR o.email LIKE :search OR o.id LIKE :search)";
    $params[':search'] = "%$search%";
}

$countSql = "SELECT COUNT(*) FROM orders o" . $where;
$countStmt = $pdo->prepare($countSql);
$countStmt->execute($params);
$totalOrders = (int)$countStmt->fetchColumn();
$totalPages = max(1, (int)ceil($totalOrders / $perPage));

$sql = "SELECT o.*, u.name AS user_name
        FROM orders o
        LEFT JOIN users u ON o.user_id = u.id" . $where . "
        ORDER BY o.created_at DESC
        LIMIT :limit OFFSET :offset";
$stmt = $pdo->prepare($sql);
foreach ($params as $k => $v) {
    $stmt->bindValue($k, $v);
}
$stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$orders = $stmt->fetchAll();

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $orderId = (int)$_POST['order_id'];
    $newStatus = $_POST['status'] ?? '';
    if (in_array($newStatus, ['pending', 'processing', 'shipped', 'delivered'])) {
        $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?")->execute([$newStatus, $orderId]);
        header("Location: orders.php?" . http_build_query(array_filter(['page' => $page, 'status' => $statusFilter, 'search' => $search])));
        exit;
    }
}

$statusLabels = [
    'pending' => ['label' => 'Menunggu', 'class' => 'warning'],
    'processing' => ['label' => 'Diproses', 'class' => 'info'],
    'shipped' => ['label' => 'Dikirim', 'class' => 'primary'],
    'delivered' => ['label' => 'Selesai', 'class' => 'success'],
];

$paymentLabels = [
    'cod' => 'Bayar di Tempat (COD)',
    'bank_transfer' => 'Transfer Bank',
    'credit_card' => 'Kartu Kredit',
];

$pageTitle = 'Daftar Pesanan';
require_once 'includes/header.php';
?>

<h1 class="mb-4"><i class="bi bi-receipt"></i> Daftar Pesanan</h1>

<!-- Filter -->
<div class="row mb-4 g-2">
    <div class="col-auto">
        <form method="GET" action="orders.php" class="d-flex gap-2">
            <select name="status" class="form-select form-select-sm" style="width:auto" onchange="this.form.submit()">
                <option value="">Semua Status</option>
                <?php foreach ($statusLabels as $key => $val): ?>
                    <option value="<?= $key ?>" <?= $statusFilter === $key ? 'selected' : '' ?>><?= $val['label'] ?></option>
                <?php endforeach; ?>
            </select>
        </form>
    </div>
    <div class="col-auto">
        <form method="GET" action="orders.php" class="d-flex gap-2">
            <?php if ($statusFilter): ?>
                <input type="hidden" name="status" value="<?= htmlspecialchars($statusFilter) ?>">
            <?php endif; ?>
            <input type="text" name="search" class="form-control form-control-sm" style="width:250px"
                   placeholder="Cari nama/email/ID..." value="<?= htmlspecialchars($search) ?>">
            <button type="submit" class="btn btn-sm btn-outline-secondary">
                <i class="bi bi-search"></i>
            </button>
        </form>
    </div>
</div>

<!-- Orders List -->
<div class="card shadow-sm">
    <div class="card-header">
        <h5 class="mb-0"><i class="bi bi-list-ul"></i> Daftar Pesanan</h5>
    </div>
    <div class="card-body">
        <?php if (count($orders) > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Pelanggan</th>
                            <th>Email</th>
                            <th>Total</th>
                            <th>Metode Bayar</th>
                            <th>Status</th>
                            <th>Tanggal</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): 
                            $statusInfo = $statusLabels[$order['status']] ?? ['label' => $order['status'], 'class' => 'secondary'];
                            $paymentLabel = $paymentLabels[$order['payment_method']] ?? $order['payment_method'];
                        ?>
                            <tr>
                                <td>#<?= $order['id'] ?></td>
                                <td><?= htmlspecialchars($order['name']) ?>
                                    <?php if ($order['user_id']): ?>
                                        <span class="badge bg-light text-dark ms-1">User: <?= htmlspecialchars($order['user_name']) ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?= htmlspecialchars($order['email']) ?></td>
                                <td class="fw-bold">Rp <?= number_format($order['total_amount'], 0, ',', '.') ?></td>
                                <td><?= $paymentLabel ?></td>
                                <td>
                                    <span class="badge bg-<?= $statusInfo['class'] ?>"><?= $statusInfo['label'] ?></span>
                                </td>
                                <td><?= date('d M Y H:i', strtotime($order['created_at'])) ?></td>
                                <td class="text-center">
                                    <form method="POST" action="orders.php" class="d-inline">
                                        <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                                        <input type="hidden" name="update_status" value="1">
                                        <?php if ($statusFilter): ?>
                                            <input type="hidden" name="status" value="<?= htmlspecialchars($statusFilter) ?>">
                                        <?php endif; ?>
                                        <?php if ($search): ?>
                                            <input type="hidden" name="search" value="<?= htmlspecialchars($search) ?>">
                                        <?php endif; ?>
                                        <input type="hidden" name="page" value="<?= $page ?>">
                                        <select name="status" class="form-select form-select-sm" onchange="this.form.submit()">
                                            <?php foreach ($statusLabels as $key => $val): ?>
                                                <option value="<?= $key ?>" <?= $order['status'] === $key ? 'selected' : '' ?>><?= $val['label'] ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($totalPages > 1): ?>
                <nav aria-label="Navigasi halaman pesanan">
                    <ul class="pagination justify-content-center mb-0">
                        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                            <a class="page-link" href="<?= $page <= 1 ? '#' : 'orders.php?' . htmlspecialchars(http_build_query(array_merge(['page' => $page - 1], $statusFilter ? ['status' => $statusFilter] : [], $search ? ['search' => $search] : []))) ?>">Sebelumnya</a>
                        </li>
                        <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                            <li class="page-item <?= $p === $page ? 'active' : '' ?>">
                                <a class="page-link" href="orders.php?<?= htmlspecialchars(http_build_query(array_merge(['page' => $p], $statusFilter ? ['status' => $statusFilter] : [], $search ? ['search' => $search] : []))) ?>"><?= $p ?></a>
                            </li>
                        <?php endfor; ?>
                        <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
                            <a class="page-link" href="<?= $page >= $totalPages ? '#' : 'orders.php?' . htmlspecialchars(http_build_query(array_merge(['page' => $page + 1], $statusFilter ? ['status' => $statusFilter] : [], $search ? ['search' => $search] : []))) ?>">Selanjutnya</a>
                        </li>
                    </ul>
                    <p class="text-center text-muted small mb-0">Halaman <?= $page ?> dari <?= $totalPages ?> (<?= $totalOrders ?> pesanan)</p>
                </nav>
            <?php endif; ?>
        <?php else: ?>
            <div class="text-center py-5">
                <i class="bi bi-receipt display-1 text-muted"></i>
                <p class="text-muted mt-3">Tidak ada pesanan ditemukan.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>