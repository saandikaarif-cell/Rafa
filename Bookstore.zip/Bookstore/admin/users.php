<?php
/**
 * admin/users.php - Kelola user yang terdaftar
 */

require_once '../config/database.php';
require_once '../includes/auth.php';

// Cek admin login
if (!isLoggedIn() || !isAdmin()) {
    redirect('login.php');
}

$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$perPage = 20;
$offset = ($page - 1) * $perPage;

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$where = '';
$params = [];

if ($search !== '') {
    $where = " WHERE name LIKE :search OR email LIKE :search";
    $params[':search'] = "%$search%";
}

$countSql = "SELECT COUNT(*) FROM users WHERE role = 'user'" . $where;
$countStmt = $pdo->prepare($countSql);
$countStmt->execute($params);
$totalUsers = (int)$countStmt->fetchColumn();
$totalPages = max(1, (int)ceil($totalUsers / $perPage));

$sql = "SELECT id, name, email, created_at FROM users WHERE role = 'user'" . $where . " ORDER BY created_at DESC LIMIT :limit OFFSET :offset";
$stmt = $pdo->prepare($sql);
foreach ($params as $k => $v) {
    $stmt->bindValue($k, $v);
}
$stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$users = $stmt->fetchAll();

$pageTitle = 'Daftar User';
require_once 'includes/header.php';
?>

<h1 class="mb-4"><i class="bi bi-people"></i> Daftar User</h1>

<!-- Search -->
<div class="row mb-4">
    <div class="col-auto">
        <form method="GET" action="users.php" class="d-flex gap-2">
            <input type="text" name="search" class="form-control form-control-sm" style="width:250px"
                   placeholder="Cari nama/email..." value="<?= htmlspecialchars($search) ?>">
            <button type="submit" class="btn btn-sm btn-outline-secondary">
                <i class="bi bi-search"></i>
            </button>
        </form>
    </div>
</div>

<!-- User List -->
<div class="card shadow-sm">
    <div class="card-header">
        <h5 class="mb-0"><i class="bi bi-list-ul"></i> Daftar User Terdaftar</h5>
    </div>
    <div class="card-body">
        <?php if (count($users) > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Terdaftar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = $offset + 1; foreach ($users as $user): ?>
                            <tr>
                                <td><?= $i++ ?></td>
                                <td><?= htmlspecialchars($user['name']) ?></td>
                                <td><?= htmlspecialchars($user['email']) ?></td>
                                <td><?= date('d M Y H:i', strtotime($user['created_at'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($totalPages > 1): ?>
                <nav aria-label="Navigasi halaman user">
                    <ul class="pagination justify-content-center mb-0">
                        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                            <a class="page-link" href="<?= $page <= 1 ? '#' : 'users.php?' . htmlspecialchars(http_build_query(array_merge(['page' => $page - 1], $search ? ['search' => $search] : []))) ?>">Sebelumnya</a>
                        </li>
                        <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                            <li class="page-item <?= $p === $page ? 'active' : '' ?>">
                                <a class="page-link" href="users.php?<?= htmlspecialchars(http_build_query(array_merge(['page' => $p], $search ? ['search' => $search] : []))) ?>"><?= $p ?></a>
                            </li>
                        <?php endfor; ?>
                        <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
                            <a class="page-link" href="<?= $page >= $totalPages ? '#' : 'users.php?' . htmlspecialchars(http_build_query(array_merge(['page' => $page + 1], $search ? ['search' => $search] : []))) ?>">Selanjutnya</a>
                        </li>
                    </ul>
                    <p class="text-center text-muted small mb-0">Halaman <?= $page ?> dari <?= $totalPages ?> (<?= $totalUsers ?> user)</p>
                </nav>
            <?php endif; ?>
        <?php else: ?>
            <div class="text-center py-5">
                <i class="bi bi-people display-1 text-muted"></i>
                <p class="text-muted mt-3">Tidak ada user ditemukan.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>