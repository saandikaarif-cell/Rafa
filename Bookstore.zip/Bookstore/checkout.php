<?php
/**
 * checkout.php - Halaman checkout
 * Form: nama, email, alamat, nomor telepon.
 * Menampilkan ringkasan pesanan dan membuat pesanan.
 */

require_once 'config/database.php';
require_once 'includes/auth.php';

$cart = $_SESSION['cart'] ?? [];

// Jika keranjang kosong, kembalikan ke cart
if (empty($cart)) {
    setFlash('message', 'Keranjang belanja Anda kosong.');
    redirect('cart.php');
}

// Hitung total
$total = 0;
foreach ($cart as $item) {
    $total += $item['price'] * $item['quantity'];
}

$errors = [];

// Jika user sudah login, ambil data otomatis
$defaultName    = getUserName() ?? '';
$defaultEmail   = '';
$defaultAddress = '';
$defaultPhone   = '';

if (isLoggedIn()) {
    $stmt = $pdo->prepare("SELECT name, email FROM users WHERE id = ?");
    $stmt->execute([getUserId()]);
    $user = $stmt->fetch();
    if ($user) {
        $defaultName  = $user['name'];
        $defaultEmail = $user['email'];
    }
}

// Proses checkout
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name           = trim($_POST['name'] ?? '');
    $email          = trim($_POST['email'] ?? '');
    $address        = trim($_POST['address'] ?? '');
    $phone          = trim($_POST['phone'] ?? '');
    $paymentMethod  = $_POST['payment_method'] ?? 'cod';

    // Validasi
    if (empty($name)) {
        $errors[] = 'Nama lengkap wajib diisi.';
    }
    if (empty($email)) {
        $errors[] = 'Email wajib diisi.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Format email tidak valid.';
    }
    if (empty($address)) {
        $errors[] = 'Alamat wajib diisi.';
    }
    if (empty($phone)) {
        $errors[] = 'Nomor telepon wajib diisi.';
    }
    if (!in_array($paymentMethod, ['cod', 'bank_transfer', 'credit_card'])) {
        $errors[] = 'Metode pembayaran tidak valid.';
    }

    // Jika tidak ada error, simpan pesanan ke database
    if (empty($errors)) {
        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("INSERT INTO orders
                (user_id, name, email, address, phone, total_amount, payment_method)
                VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                isLoggedIn() ? getUserId() : null,
                $name,
                $email,
                $address,
                $phone,
                $total,
                $paymentMethod
            ]);
            $orderId = $pdo->lastInsertId();

            $stmt = $pdo->prepare("INSERT INTO order_details
                (order_id, book_id, quantity, price)
                VALUES (?, ?, ?, ?)");

            foreach ($cart as $bookId => $item) {
                $stmt->execute([
                    $orderId,
                    $bookId,
                    $item['quantity'],
                    $item['price']
                ]);
            }

            $pdo->commit();
            unset($_SESSION['cart']);

            setFlash('message', 'Pesanan #' . $orderId . ' berhasil dibuat. Terima kasih!');
            redirect('index.php');
        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = 'Terjadi kesalahan saat menyimpan pesanan. Silakan coba lagi.';
        }
    }
}

require_once 'includes/header.php';
?>

<div class="row">
    <div class="col-lg-8">
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0"><i class="bi bi-credit-card"></i> Form Checkout</h4>
            </div>
            <div class="card-body">

                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php foreach ($errors as $error): ?>
                                <li><?= $error ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="POST" action="checkout.php">
                    <div class="mb-3">
                        <label class="form-label">Nama Lengkap</label>
                        <input type="text" name="name" class="form-control"
                               value="<?= htmlspecialchars($defaultName) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control"
                               value="<?= htmlspecialchars($defaultEmail) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Alamat Lengkap</label>
                        <textarea name="address" class="form-control" rows="3"
                                  placeholder="Masukkan alamat lengkap..." required><?= htmlspecialchars($defaultAddress) ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Nomor Telepon</label>
                        <input type="tel" name="phone" class="form-control"
                               placeholder="08xx-xxxx-xxxx" value="<?= htmlspecialchars($defaultPhone) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Metode Pembayaran</label>
                        <div class="row g-2">
                            <div class="col-md-6">
                                <div class="form-check border p-3 h-100">
                                    <input class="form-check-input" type="radio" name="payment_method" id="payment_cod"
                                           value="cod" checked>
                                    <label class="form-check-label fw-bold" for="payment_cod">
                                        <i class="bi bi-cash text-success"></i> Bayar di Tempat (COD)
                                    </label>
                                    <div class="form-text small">Bayar saat barang diterima</div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-check border p-3 h-100">
                                    <input class="form-check-input" type="radio" name="payment_method" id="payment_transfer"
                                           value="bank_transfer">
                                    <label class="form-check-label fw-bold" for="payment_transfer">
                                        <i class="bi bi-bank text-primary"></i> Transfer Bank
                                    </label>
                                    <div class="form-text small">Transfer ke rekening kami</div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-check border p-3 h-100">
                                    <input class="form-check-input" type="radio" name="payment_method" id="payment_card"
                                           value="credit_card">
                                    <label class="form-check-label fw-bold" for="payment_card">
                                        <i class="bi bi-credit-card text-info"></i> Kartu Kredit
                                    </label>
                                    <div class="form-text small">Pembayaran via kartu</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-success btn-lg w-100">
                        <i class="bi bi-check-circle"></i> Buat Pesanan
                    </button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="card shadow-sm order-summary">
            <div class="card-header">
                <h4 class="mb-0"><i class="bi bi-receipt"></i> Ringkasan Pesanan</h4>
            </div>
            <div class="card-body">
                <ul class="list-group list-group-flush">
                    <?php foreach ($cart as $item): ?>
                        <li class="list-group-item px-0">
                            <div class="d-flex gap-3">
                                <img src="assets/image/<?= $item['image'] ?? 'no-image.jpg' ?>"
                                     class="cart-book-img"
                                     alt="<?= htmlspecialchars($item['title']) ?>">
                                <div class="flex-grow-1">
                                    <div class="fw-medium"><?= htmlspecialchars($item['title']) ?></div>
                                    <small class="text-muted">x<?= $item['quantity'] ?></small>
                                </div>
                                <div class="text-end">
                                    <div class="fw-medium">Rp <?= number_format($item['price'] * $item['quantity'], 0, ',', '.') ?></div>
                                </div>
                            </div>
                        </li>
                    <?php endforeach; ?>
                    <li class="list-group-item px-0 d-flex justify-content-between fw-bold border-top mt-2">
                        <span>Total:</span>
                        <span class="book-price fs-5">Rp <?= number_format($total, 0, ',', '.') ?></span>
                    </li>
                    <li class="list-group-item px-0 d-flex justify-content-between text-muted small">
                        <span>Metode Bayar:</span>
                        <span>
                            <?php
                                $pm = $_POST['payment_method'] ?? 'cod';
                                $labels = [
                                    'cod' => 'Bayar di Tempat (COD)',
                                    'bank_transfer' => 'Transfer Bank',
                                    'credit_card' => 'Kartu Kredit'
                                ];
                                echo $labels[$pm] ?? 'COD';
                            ?>
                        </span>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>

