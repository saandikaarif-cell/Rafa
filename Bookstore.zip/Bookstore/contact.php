<?php
/**
 * contact.php - Halaman Hubungi Kami
 * Form kirim pesan ke admin
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/database.php';
require_once 'includes/auth.php';

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'], $token)) {
        $errors[] = 'Permintaan tidak valid. Silakan coba lagi.';
    }

    $name    = trim($_POST['name'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if (empty($name)) {
        $errors[] = 'Nama lengkap wajib diisi.';
    }
    if (empty($email)) {
        $errors[] = 'Email wajib diisi.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Format email tidak valid.';
    }
    if (empty($subject)) {
        $errors[] = 'Subjek wajib diisi.';
    }
    if (empty($message)) {
        $errors[] = 'Pesan wajib diisi.';
    } elseif (strlen($message) < 10) {
        $errors[] = 'Pesan minimal 10 karakter.';
    }

    if (empty($errors)) {
        try {
            $userId = isLoggedIn() ? getUserId() : null;
            $stmt = $pdo->prepare("INSERT INTO messages (user_id, name, email, subject, message) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$userId, $name, $email, $subject, $message]);
            setFlash('contact_success', 'Pesan Anda telah terkirim. Tim kami akan segera merespons.');
            header("Location: contact.php");
            exit;
        } catch (PDOException $e) {
            $errors[] = 'Database error: ' . $e->getMessage();
        } catch (Exception $e) {
            $errors[] = 'Terjadi kesalahan: ' . $e->getMessage();
        }
    }
}

$success = getFlash('contact_success');

require_once 'includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-4 p-md-5 text-center">
                <h1 class="fw-bold mb-3">Hubungi Kami</h1>
                <p class="lead mb-0 opacity-75">Kami siap mendengar keluhan, saran, atau pertanyaan Anda.</p>
            </div>
        </div>

        <?php if ($success): ?>
            <div class="alert alert-success d-flex align-items-center" role="alert">
                <i class="bi bi-check-circle-fill me-2"></i>
                <div><?= htmlspecialchars($success) ?></div>
            </div>
        <?php endif; ?>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger d-flex align-items-center" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2"></i>
                <div>
                    <?php foreach ($errors as $error): ?>
                        <div><?= htmlspecialchars($error) ?></div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <form method="POST" action="contact.php">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                    <input type="text" name="name" class="form-control"
                           value="<?= htmlspecialchars($name ?? (isLoggedIn() ? getUserName() : '')) ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Email <span class="text-danger">*</span></label>
                    <input type="email" name="email" class="form-control"
                           value="<?= htmlspecialchars($email ?? (isLoggedIn() ? $_SESSION['email'] ?? '' : '')) ?>" required>
                </div>
                <div class="col-12">
                    <label class="form-label">Subjek <span class="text-danger">*</span></label>
                    <select name="subject" class="form-select" required>
                        <option value="">-- Pilih Subjek --</option>
                        <option value="Pertanyaan Umum" <?= ($subject ?? '') === 'Pertanyaan Umum' ? 'selected' : '' ?>>Pertanyaan Umum</option>
                        <option value="Keluhan Pesanan" <?= ($subject ?? '') === 'Keluhan Pesanan' ? 'selected' : '' ?>>Keluhan Pesanan</option>
                        <option value="Saran & Masukan" <?= ($subject ?? '') === 'Saran & Masukan' ? 'selected' : '' ?>>Saran & Masukan</option>
                        <option value="Lainnya" <?= ($subject ?? '') === 'Lainnya' ? 'selected' : '' ?>>Lainnya</option>
                    </select>
                </div>
                <div class="col-12">
                    <label class="form-label">Pesan <span class="text-danger">*</span></label>
                    <textarea name="message" class="form-control" rows="5" placeholder="Tulis pesan Anda di sini..." required><?= htmlspecialchars($message ?? '') ?></textarea>
                    <div class="form-text">Minimal 10 karakter</div>
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i class="bi bi-send me-2"></i>Kirim Pesan
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
