<?php
/**
 * includes/footer.php
 * Footer halaman utama.
 */
?>
</main>

<footer class="site-footer mt-5">
    <div class="container text-center py-4">
        <img class="footer-logo" src="assets/image/logo-bookstore.svg" alt="Bookstore">
        <p class="footer-tagline mb-2">Temukan dunia baru di setiap halaman.</p>
        <p class="footer-copy mb-0">&copy; <?= date('Y') ?> Bookstore. All rights reserved.</p>
    </div>
</footer>

<!-- Bootstrap 5 JS + Popper (CDN) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Custom JS -->
<script src="assets/jss/cart.js"></script>
</body>
</html>