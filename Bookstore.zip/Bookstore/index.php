<?php
/**
 * index.php - Halaman utama (Home)
 * Menampilkan daftar buku, fitur search berdasarkan judul,
 * dan filter berdasarkan kategori.
 */

require_once 'config/database.php';
require_once 'includes/auth.php';

// --- Ambil parameter pencarian & filter ---
$search   = isset($_GET['search'])   ? trim($_GET['search']) : '';
$category = isset($_GET['category']) ? (int)$_GET['category'] : 0;
$page     = isset($_GET['page'])     ? max(1, (int)$_GET['page']) : 1;
$perPage  = 12;
$offset   = ($page - 1) * $perPage;

// --- Build query dengan prepared statements ---
$where = " WHERE 1=1";
$params = [];

if ($category > 0) {
    $where .= " AND b.category_id = :category";
    $params[':category'] = $category;
}

if ($search !== '') {
    $where .= " AND (b.title LIKE :search OR c.name LIKE :search2)";
    $params[':search'] = "%$search%";
    $params[':search2'] = "%$search%";
}

$countSql = "SELECT COUNT(*) FROM books b LEFT JOIN categories c ON b.category_id = c.id" . $where;
$countStmt = $pdo->prepare($countSql);
$countStmt->execute($params);
$totalBooks = (int)$countStmt->fetchColumn();
$totalPages = max(1, (int)ceil($totalBooks / $perPage));
if ($page > $totalPages) {
    $page = $totalPages;
    $offset = ($page - 1) * $perPage;
}

$sql = "SELECT b.id, b.title, b.author, b.price, b.image, b.description, c.name AS category_name
        FROM books b
        LEFT JOIN categories c ON b.category_id = c.id" . $where . "
        ORDER BY b.created_at DESC
        LIMIT :limit OFFSET :offset";

$stmt = $pdo->prepare($sql);
foreach ($params as $k => $v) {
    $stmt->bindValue($k, $v);
}
$stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$books = $stmt->fetchAll();

$pageParams = [];
if ($search !== '') {
    $pageParams['search'] = $search;
}
if ($category > 0) {
    $pageParams['category'] = $category;
}

require_once 'includes/header.php';
?>

<!-- Flash Message -->
<?php
$flash = getFlash('message');
if ($flash): ?>
    <div class="alert alert-success alert-dismissible fade show flash-message" role="alert">
        <?= $flash ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Book List -->
<?php if (count($books) > 0): ?>
    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4">
        <?php foreach ($books as $book): ?>
            <div class="col">
                <div class="card book-card h-100">
                    <img src="assets/image/<?= $book['image'] ?: 'no-image.jpg' ?>"
                         class="book-img card-img-top" alt="<?= htmlspecialchars($book['title']) ?>">
                    <div class="card-body d-flex flex-column">
                        <h6 class="card-title"><?= htmlspecialchars($book['title']) ?></h6>
                        <p class="book-meta mb-1">
                            <i class="bi bi-person"></i> <?= htmlspecialchars($book['author']) ?>
                        </p>
                        <p class="book-meta mb-2">
                            <i class="bi bi-folder"></i> <?= htmlspecialchars($book['category_name']) ?>
                        </p>
                        <div class="mt-auto d-flex justify-content-between align-items-center">
                            <span class="book-price">Rp <?= number_format($book['price'], 0, ',', '.') ?></span>
                            <a href="detail.php?id=<?= $book['id'] ?>" class="btn btn-sm btn-outline-primary">Detail</a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <?php if ($totalPages > 1): ?>
        <nav class="mt-4" aria-label="Navigasi halaman buku">
            <ul class="pagination justify-content-center mb-1">
                <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                    <a class="page-link" href="<?= $page <= 1 ? '#' : 'index.php?' . htmlspecialchars(http_build_query($pageParams + ['page' => $page - 1])) ?>">Sebelumnya</a>
                </li>
                <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                    <li class="page-item <?= $p === $page ? 'active' : '' ?>">
                        <a class="page-link" href="index.php?<?= htmlspecialchars(http_build_query($pageParams + ['page' => $p])) ?>"><?= $p ?></a>
                    </li>
                <?php endfor; ?>
                <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
                    <a class="page-link" href="<?= $page >= $totalPages ? '#' : 'index.php?' . htmlspecialchars(http_build_query($pageParams + ['page' => $page + 1])) ?>">Next</a>
                </li>
            </ul>
            <p class="text-center text-muted small mb-0">Halaman <?= $page ?> dari <?= $totalPages ?> (<?= $totalBooks ?> buku)</p>
        </nav>
    <?php endif; ?>
<?php else: ?>
    <div class="text-center py-5">
        <i class="bi bi-book display-1 text-muted"></i>
        <p class="text-muted mt-3">Tidak ada buku ditemukan.</p>
    </div>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
