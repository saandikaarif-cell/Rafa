<?php
/**
 * login.php - Halaman login user
 * Login menggunakan email dan password.
 * Password disimpan menggunakan password hashing (password_hash / password_verify).
 */

require_once 'config/database.php';
require_once 'includes/auth.php';

// Jika sudah login, redirect ke beranda
if (isLoggedIn()) {
    redirect('index.php');
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    // Validasi input
    if (empty($email)) {
        $errors[] = 'Email wajib diisi.';
    }
    if (empty($password)) {
        $errors[] = 'Password wajib diisi.';
    }

    // Jika tidak ada error, cek ke database (hanya akun user)
    if (empty($errors)) {
        $stmt = $pdo->prepare("SELECT id, name, password, role FROM users WHERE email = ? AND role = 'user'");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            // Login berhasil - simpan data ke session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['name']    = $user['name'];
            $_SESSION['role']    = $user['role'];

            setFlash('message', 'Login berhasil! Selamat belanja di Bookstore.');
            redirect('index.php');
        } else {
            $errors[] = 'Email atau password salah.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Bookstore</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="auth-page">
<div class="card auth-card">
    <div class="auth-header">
        <div class="logo">
            <i class="bi bi-book"></i>
        </div>
        <h3>Masuk ke Bookstore</h3>
        <p>Masuk untuk melanjutkan belanja</p>
    </div>
    <div class="auth-body">
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger d-flex align-items-center" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2"></i>
                <div>
                    <?php foreach ($errors as $error): ?>
                        <div><?= $error ?></div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <form method="POST" action="login.php">
            <div class="form-floating mb-3">
                <input type="email" name="email" class="form-control" id="email"
                       placeholder="contoh@email.com" required autofocus autocomplete="email">
                <label for="email"><i class="bi bi-envelope me-2"></i>Email</label>
            </div>
            <div class="form-floating mb-4">
                <input type="password" name="password" class="form-control" id="password"
                       placeholder="Password" required autocomplete="current-password">
                <label for="password"><i class="bi bi-lock me-2"></i>Password</label>
            </div>
            <button type="submit" class="btn btn-primary btn-auth w-100">
                <i class="bi bi-box-arrow-in-right me-2"></i>Masuk
            </button>
        </form>

        <div class="text-center mt-4">
            <small class="text-muted">Belum punya akun? <a href="register.php">Daftar sekarang</a></small>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>