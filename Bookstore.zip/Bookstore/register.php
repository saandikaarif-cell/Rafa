<?php
/**
 * register.php - Halaman registrasi user baru
 * Membuat akun dengan email & password yang di-hash.
 */

require_once 'config/database.php';
require_once 'includes/auth.php';

// Jika sudah login, redirect ke beranda
if (isLoggedIn()) {
    redirect('index.php');
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm'] ?? '';

    // Validasi
    if (empty($name)) {
        $errors[] = 'Nama lengkap wajib diisi.';
    }
    if (empty($email)) {
        $errors[] = 'Email wajib diisi.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Format email tidak valid.';
    }
    if (empty($password)) {
        $errors[] = 'Password wajib diisi.';
    }
    if ($password !== $confirm) {
        $errors[] = 'Konfirmasi password tidak cocok.';
    }

    // Cek apakah email sudah terdaftar
    if (empty($errors)) {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $errors[] = 'Email sudah terdaftar. Silakan login.';
        }
    }

    // Registrasi
    if (empty($errors)) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, 'user')");
        $stmt->execute([$name, $email, $hashedPassword]);

        setFlash('message', 'Registrasi berhasil! Silakan login.');
        redirect('login.php');
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar - Bookstore</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="auth-page">
<div class="card auth-card">
    <div class="auth-header">
        <div class="logo">
            <i class="bi bi-person-plus"></i>
        </div>
        <h3>Buat Akun Baru</h3>
        <p>Bergabung dengan Bookstore hari ini</p>
    </div>
    <div class="auth-body">
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger d-flex align-items-center" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2"></i>
                <div>
                    <?php foreach ($errors as $error): ?>
                        <div><?= $error ?></div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <form method="POST" action="register.php">
            <div class="form-floating mb-3">
                <input type="text" name="name" class="form-control" id="name"
                       placeholder="Nama lengkap" required autofocus autocomplete="name">
                <label for="name"><i class="bi bi-person me-2"></i>Nama Lengkap</label>
            </div>
            <div class="form-floating mb-3">
                <input type="email" name="email" class="form-control" id="email"
                       placeholder="contoh@email.com" required autocomplete="email">
                <label for="email"><i class="bi bi-envelope me-2"></i>Email</label>
            </div>
            <div class="form-floating mb-3">
                <input type="password" name="password" class="form-control" id="password"
                       placeholder="Minimal 6 karakter" required autocomplete="new-password" minlength="6">
                <label for="password"><i class="bi bi-lock me-2"></i>Password</label>
            </div>
            <div class="form-floating mb-4">
                <input type="password" name="confirm" class="form-control" id="confirm"
                       placeholder="Ulangi password" required autocomplete="new-password">
                <label for="confirm"><i class="bi bi-lock-fill me-2"></i>Konfirmasi Password</label>
            </div>
            <button type="submit" class="btn btn-primary btn-auth w-100">
                <i class="bi bi-person-plus me-2"></i>Daftar
            </button>
        </form>

        <div class="text-center mt-4">
            <small class="text-muted">Sudah punya akun? <a href="login.php">Login di sini</a></small>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>